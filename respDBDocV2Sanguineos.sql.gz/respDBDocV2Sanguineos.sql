-- MySQL dump 10.16  Distrib 10.1.34-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: db_doctores
-- ------------------------------------------------------
-- Server version	10.1.34-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `c_estadosciviles`
--

DROP TABLE IF EXISTS `c_estadosciviles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `c_estadosciviles` (
  `clave` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `status` bit(1) DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_estadosciviles`
--

LOCK TABLES `c_estadosciviles` WRITE;
/*!40000 ALTER TABLE `c_estadosciviles` DISABLE KEYS */;
INSERT INTO `c_estadosciviles` VALUES (1,'SOLTERO(A)',''),(2,'CASADO(A)','');
/*!40000 ALTER TABLE `c_estadosciviles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_familiares`
--

DROP TABLE IF EXISTS `c_familiares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `c_familiares` (
  `clave` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(70) DEFAULT NULL,
  `status` bit(1) DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_familiares`
--

LOCK TABLES `c_familiares` WRITE;
/*!40000 ALTER TABLE `c_familiares` DISABLE KEYS */;
INSERT INTO `c_familiares` VALUES (1,'---',''),(2,'PADRE',''),(3,'MADRE',''),(4,'HERMANA',''),(5,'HERMANO',''),(6,'ABUELO PATERNO',''),(7,'ABUELO MATERNO','');
/*!40000 ALTER TABLE `c_familiares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_medicamentos`
--

DROP TABLE IF EXISTS `c_medicamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `c_medicamentos` (
  `clave` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `status` bit(1) DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_medicamentos`
--

LOCK TABLES `c_medicamentos` WRITE;
/*!40000 ALTER TABLE `c_medicamentos` DISABLE KEYS */;
INSERT INTO `c_medicamentos` VALUES (1,'KINUBERASE TABS 500MG','');
/*!40000 ALTER TABLE `c_medicamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `c_tratamientos`
--

DROP TABLE IF EXISTS `c_tratamientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `c_tratamientos` (
  `clave` smallint(6) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `status` bit(1) DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `c_tratamientos`
--

LOCK TABLES `c_tratamientos` WRITE;
/*!40000 ALTER TABLE `c_tratamientos` DISABLE KEYS */;
INSERT INTO `c_tratamientos` VALUES (1,'TOMAR UNO CADA 8 HORAS DURANTE 3 DIAS','');
/*!40000 ALTER TABLE `c_tratamientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `h_clinica`
--

DROP TABLE IF EXISTS `h_clinica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `h_clinica` (
  `id_clinica` int(11) NOT NULL AUTO_INCREMENT,
  `expediente` double NOT NULL,
  `diabetes` varchar(50) DEFAULT NULL,
  `hepatopatia` varchar(50) DEFAULT NULL,
  `asma` varchar(50) DEFAULT NULL,
  `endocrinas` varchar(50) DEFAULT NULL,
  `hipertension` varchar(50) DEFAULT NULL,
  `nefropatia` varchar(50) DEFAULT NULL,
  `cancer` varchar(50) DEFAULT NULL,
  `cardiopatia` varchar(50) DEFAULT NULL,
  `mentales` varchar(50) DEFAULT NULL,
  `alergicas` varchar(50) DEFAULT NULL,
  `otrosHF` varchar(50) DEFAULT NULL,
  `actuales` varchar(50) DEFAULT NULL,
  `quirurgicas` varchar(50) DEFAULT NULL,
  `transfusionales` varchar(50) DEFAULT NULL,
  `alergias` varchar(50) DEFAULT NULL,
  `traumaticas` varchar(50) DEFAULT NULL,
  `hospitalizaciones` varchar(50) DEFAULT NULL,
  `adicciones` varchar(50) DEFAULT NULL,
  `otrosPer` varchar(50) DEFAULT NULL,
  `baño` varchar(25) DEFAULT NULL,
  `habitacion` varchar(25) DEFAULT NULL,
  `alimentacion` varchar(25) DEFAULT NULL,
  `deportes` varchar(25) DEFAULT NULL,
  `inmunizaciones` varchar(25) DEFAULT NULL,
  `descinmunizaciones` varchar(25) DEFAULT NULL,
  `alcoholismo` bit(1) DEFAULT NULL,
  `frecuencia` varchar(25) DEFAULT NULL,
  `añosAlc` varchar(25) DEFAULT NULL,
  `tabaquismo` bit(1) DEFAULT NULL,
  `cigdia` varchar(25) DEFAULT NULL,
  `añosTabaq` varchar(25) DEFAULT NULL,
  `anotacion` mediumtext,
  PRIMARY KEY (`id_clinica`),
  KEY `expediente` (`expediente`),
  CONSTRAINT `fk_paciente` FOREIGN KEY (`expediente`) REFERENCES `t_personales` (`expediente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `h_clinica`
--

LOCK TABLES `h_clinica` WRITE;
/*!40000 ALTER TABLE `h_clinica` DISABLE KEYS */;
INSERT INTO `h_clinica` VALUES (1,1,'HERMANA','/','PADRE','/','/','/','/','/','/','/','PADECE ARRITMIA DESDE 1999','ENFERMEDAD DE HALS HEIMER','/','/','/','/','/','/','ONCOLOGIA CLINICA','DIARIO','URBANA','4','/','PENDIENTES','TETANOS','','4','5','\0','/','/','27/12/2019 REALIZAR EXAMEN GENERAL DE ORINA, ADEMAS DE TDA:120'),(2,5,'MADRE','/','HERMANA','/','/','/','MADRE','/','/','/','TIO LEPROSO','GONORREA Y SIFILIS','/','/','/','/','/','/','VIH POSITIVO','DIARIO','URBANA','/','/','COMPLETAS','/','','5','2','\0','/','/','/');
/*!40000 ALTER TABLE `h_clinica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sanguineos`
--

DROP TABLE IF EXISTS `sanguineos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sanguineos` (
  `id_sanguineo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `no_exped` double DEFAULT NULL,
  `fechExam` date DEFAULT NULL,
  `hemoglobina` varchar(10) DEFAULT NULL,
  `hbcm` varchar(10) DEFAULT NULL,
  `plaquetas` varchar(10) DEFAULT NULL,
  `leucocitos` varchar(10) DEFAULT NULL,
  `neutrofilos` varchar(10) DEFAULT NULL,
  `linfocitos` varchar(10) DEFAULT NULL,
  `hematocrito` varchar(10) DEFAULT NULL,
  `glucosa` varchar(10) DEFAULT NULL,
  `urea` varchar(10) DEFAULT NULL,
  `creatinina` varchar(10) DEFAULT NULL,
  `acurico` varchar(10) DEFAULT NULL,
  `colesterol` varchar(10) DEFAULT NULL,
  `trigliceridos` varchar(10) DEFAULT NULL,
  `hbglucosilada` varchar(10) DEFAULT NULL,
  `bilirrubinas` varchar(10) DEFAULT NULL,
  `ast` varchar(10) DEFAULT NULL,
  `alt` varchar(10) DEFAULT NULL,
  `dhl` varchar(10) DEFAULT NULL,
  `tp` varchar(10) DEFAULT NULL,
  `ttp` varchar(10) DEFAULT NULL,
  `cpk` varchar(10) DEFAULT NULL,
  `freumatoide` varchar(10) DEFAULT NULL,
  `tsh` varchar(10) DEFAULT NULL,
  `t4libre` varchar(10) DEFAULT NULL,
  `t3libre` varchar(10) DEFAULT NULL,
  `anotac` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_sanguineo`),
  KEY `no_exped` (`no_exped`),
  CONSTRAINT `sanguineos_ibfk_1` FOREIGN KEY (`no_exped`) REFERENCES `t_personales` (`expediente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sanguineos`
--

LOCK TABLES `sanguineos` WRITE;
/*!40000 ALTER TABLE `sanguineos` DISABLE KEYS */;
INSERT INTO `sanguineos` VALUES (1,5,'2020-01-07','10','2','2','2','2','2','/','12','/','/','/','/','/','/','1.0','/','/','/','/','/','/','100','/','/','/','/'),(2,5,'2020-01-01','100%','/','/','25.2','3.3','/','/','/','/','/','/','1','1','1','/','/','/','/','/','/','/','/','/','/','/','HACER RADIOGRAFIA');
/*!40000 ALTER TABLE `sanguineos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_consultas`
--

DROP TABLE IF EXISTS `t_consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_consultas` (
  `id_consultas` int(11) NOT NULL AUTO_INCREMENT,
  `expediente` double DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `peso` float DEFAULT NULL,
  `estatura` int(11) DEFAULT NULL,
  `TA` varchar(50) DEFAULT NULL,
  `diagnostico` mediumtext,
  `notaMedica` varchar(200) DEFAULT NULL,
  `cita` tinyint(4) DEFAULT NULL,
  `fechacita` date DEFAULT NULL,
  `horaCita` time NOT NULL DEFAULT '09:00:00',
  `costo` decimal(7,2) NOT NULL DEFAULT '500.00',
  `status` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id_consultas`),
  KEY `expediente` (`expediente`),
  CONSTRAINT `fk_consultas_personales` FOREIGN KEY (`expediente`) REFERENCES `t_personales` (`expediente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_consultas`
--

LOCK TABLES `t_consultas` WRITE;
/*!40000 ALTER TABLE `t_consultas` DISABLE KEYS */;
INSERT INTO `t_consultas` VALUES (1,1,'2019-12-29',70,171,'120','/','',1,'2019-12-30','09:00:00',900.00,'\0'),(2,1,'2019-12-30',73,171,'130','OK','REALIZAR ESTUDIOS GENERAL',1,'2019-12-31','12:05:00',500.00,''),(3,2,'2019-12-30',78,164,'125','ESTA OBESA','REALIZAR ELECTROCARDIOGRAMA',1,'2020-01-01','10:15:00',800.00,'\0'),(4,5,'2020-01-07',130,180,'120','OBESIDAD SEVERA','ESTUDIOS DE TRIGLICERIDOS',1,'2020-01-29','10:15:00',650.00,'\0');
/*!40000 ALTER TABLE `t_consultas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_personales`
--

DROP TABLE IF EXISTS `t_personales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_personales` (
  `expediente` double NOT NULL,
  `fecha` date DEFAULT NULL COMMENT 'fue modificada por la migracion',
  `nombre` varchar(30) DEFAULT NULL,
  `apellidos` varchar(30) DEFAULT NULL,
  `edad` date DEFAULT '1990-11-11',
  `estadocivil` smallint(6) DEFAULT NULL,
  `calle` varchar(50) DEFAULT NULL,
  `poblacion` varchar(50) DEFAULT NULL,
  `telefono` varchar(13) DEFAULT NULL,
  `celular` varchar(13) DEFAULT NULL,
  `gestas` varchar(10) DEFAULT NULL,
  `partos` varchar(10) DEFAULT NULL,
  `abortos` varchar(10) DEFAULT NULL,
  `cesareas` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`expediente`),
  KEY `fk_estadocivil` (`estadocivil`),
  CONSTRAINT `fk_estadocivil` FOREIGN KEY (`estadocivil`) REFERENCES `c_estadosciviles` (`clave`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_personales`
--

LOCK TABLES `t_personales` WRITE;
/*!40000 ALTER TABLE `t_personales` DISABLE KEYS */;
INSERT INTO `t_personales` VALUES (1,'2019-12-29','ANTONIO','NOTARIO RODRIGUEZ','1990-11-11',1,'11 ORIENTE 1804','TECAMACHALCO','M','2211688853',NULL,NULL,NULL,NULL),(2,'2019-12-30','OLIVIA','NOTARIO RODRIGUEZ','1978-07-27',1,'11 ORIENTE 1804','TECAMACHALCO PUEBLA','F','221234455','3','3','0','1'),(3,'2020-01-06','ESPERANZA','ALVARADO PINEDA','1992-01-17',1,'11 ORIENTE','SAN BALTAZAR CAMPECHE','F','2225984218','0','0','0','0'),(4,'2020-01-06','SOCORRO','RODRIGUEZ ROSSINI','1954-11-21',2,'11 ORIENTE','LA VILLITA TECAMACHALCO PUEBLA','F','2223452312','6','6','0','2'),(5,'2020-01-07','JOSE GUADALUPE','SANCHEZ FLORES','1984-06-01',1,'11 ORIENTE 1804','LA VILLITA TECAMACHALCO','M','2245896565','/','/','/','/');
/*!40000 ALTER TABLE `t_personales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_recetas`
--

DROP TABLE IF EXISTS `t_recetas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_recetas` (
  `id_Receta` int(11) NOT NULL AUTO_INCREMENT,
  `id_consultas` int(11) NOT NULL,
  `expediente` double DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `medicamento` smallint(6) DEFAULT NULL,
  `tratamiento` smallint(6) DEFAULT NULL,
  `prioridad` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id_Receta`),
  KEY `id_consultas` (`id_consultas`),
  KEY `medicamento` (`medicamento`),
  KEY `tratamiento` (`tratamiento`),
  CONSTRAINT `fk_medicamentos` FOREIGN KEY (`medicamento`) REFERENCES `c_medicamentos` (`clave`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_recetas_consultas` FOREIGN KEY (`id_consultas`) REFERENCES `t_consultas` (`id_consultas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tratamientos` FOREIGN KEY (`tratamiento`) REFERENCES `c_tratamientos` (`clave`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_recetas`
--

LOCK TABLES `t_recetas` WRITE;
/*!40000 ALTER TABLE `t_recetas` DISABLE KEYS */;
INSERT INTO `t_recetas` VALUES (5,1,1,'2019-12-29',1,1,1),(6,1,1,'2019-12-29',1,1,1),(7,2,1,'2019-12-30',1,1,1),(8,2,1,'2019-12-30',1,1,1),(9,3,2,'2019-12-30',1,1,1),(10,3,2,'2019-12-30',1,1,1),(11,3,2,'2019-12-30',1,1,1),(12,3,2,'2019-12-30',1,1,1),(13,3,2,'2019-12-30',1,1,1),(14,4,5,'2020-01-07',1,1,1),(15,4,5,'2020-01-07',1,1,1),(16,4,5,'2020-01-07',1,1,1);
/*!40000 ALTER TABLE `t_recetas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'db_doctores'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-07 22:00:38
